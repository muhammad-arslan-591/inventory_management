from django.apps import AppConfig


class SetupManagementConfig(AppConfig):
    name = 'setup_management'
