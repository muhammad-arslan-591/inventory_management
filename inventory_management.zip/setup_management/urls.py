from django.urls import path

from .views import *

urlpatterns = [
    path('', add_city_area, name="add_city_area"),
    path('city/area/', add_city_area, name="add_city_area"),
    path('get_city_areas/', get_city_areas, name="get_city_areas"),
    path('warehouse/', warehouse, name="warehouse"),
]