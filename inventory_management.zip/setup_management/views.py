import json
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from .models import *
from core.utils import sequence_id


# Create your views here.


def add_city_area(request):
    city_list = CityAreaMapping.objects.filter(ca_parent_id=0).order_by().values('ca_id', 'ca_city').distinct()

    if request.POST:
        city = request.POST.get('city')
        area = request.POST.get('area')
        parent_id = 0
        city_name = ''
        area_existence = ''
        add_record = True
        add_two_records = False
        message = "Record Saved Successfully"
        print("city: " + city + ", area: " + area)

        city_existence, city = city.split('~')
        print(city_existence + " " + city)

        if area and city_existence == "old":
            parent_id = city
            area_existence, area = area.split('~')
            print(area_existence + " " + area)
        elif area and city_existence == "new":
            city_name = city
            area_existence, area = area.split('~')
            print(area_existence + " " + area)
        elif not area and city_existence == "old":
            add_record = False
            message = "City exists already"
        else:
            city_name = city

        if area_existence == "new" and city_existence == "new":
            add_two_records = True

        if area_existence == "old" and city_existence == "old":
            add_record = False
            message = "City and area exists already"

        city_area_model = CityAreaMapping()

        if add_two_records:
            insert_id = sequence_id("CITY_AREA_MAPPING", "CA_ID")
            city_area_model.ca_id = insert_id
            city_area_model.ca_parent_id = parent_id
            city_area_model.ca_city = city_name
            city_area_model.ca_area = ''
            if add_record:
                city_area_model.save()

            city_area_model.ca_id = sequence_id("CITY_AREA_MAPPING", "CA_ID")
            city_area_model.ca_parent_id = insert_id
            city_area_model.ca_city = ''
            city_area_model.ca_area = area
            if add_record:
                city_area_model.save()
        else:
            city_area_model.ca_id = sequence_id("CITY_AREA_MAPPING", "CA_ID")
            city_area_model.ca_parent_id = parent_id
            city_area_model.ca_city = city_name
            city_area_model.ca_area = area
            if add_record:
                city_area_model.save()

        return render(request, "setup_management/add_city_area.html", {'city_list': city_list, 'message': message})

    return render(request, "setup_management/add_city_area.html", {'city_list': city_list})


def warehouse(request):
    wareHouseList = Warehouse.objects.all()

    if request.POST:

        print(request.POST)

        wh_name = request.POST.get('wh_name')
        wh_phone = request.POST.get('wh_phone')
        wh_address = request.POST.get('wh_address')

        warehouse_obj = Warehouse()
        warehouse_obj.wh_id = sequence_id("WAREHOUSE", "WH_ID")
        warehouse_obj.wh_name = wh_name
        warehouse_obj.wh_phone = wh_phone
        warehouse_obj.wh_address = wh_address
        warehouse_obj.save()

        return redirect('warehouse')

    return render(request, "setup_management/warehouse.html", {"wareHouseList": wareHouseList})


# this function will receive ajax request and return areas against city id
def get_city_areas(request):
    if request.GET:
        city_id = request.GET.get('city_id')
        areas_list = CityAreaMapping.objects.filter(ca_parent_id=city_id).order_by().values('ca_id', 'ca_area').distinct()
        return JsonResponse({"areas_list": list(areas_list)})
