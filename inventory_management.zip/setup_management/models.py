from django.db import models
from django.utils import timezone

# Create your models here.


class CityAreaMapping(models.Model):
    ca_id = models.IntegerField(primary_key=True)
    ca_parent_id = models.IntegerField()
    ca_city = models.CharField(max_length=40, blank=True, default='')
    ca_area = models.CharField(max_length=70, blank=True, default='')
    ca_created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        db_table = "city_area_mapping"


class Warehouse(models.Model):
    wh_id = models.IntegerField(primary_key=True)
    wh_name = models.CharField(max_length=40, blank=False)
    wh_phone = models.CharField(max_length=20, blank=True, default='')
    wh_address = models.CharField(max_length=70, blank=True, default='')
    wh_created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        db_table = "warehouse"
