from django.apps import AppConfig


class CustomerManagementConfig(AppConfig):
    name = 'customer_management'
