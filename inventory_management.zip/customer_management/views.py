from django.shortcuts import render
from setup_management.models import *

# Create your views here.


def customers_list(request):
    return render(request, "customer_management/customers.html")


def add_customer(request):

    city_list = CityAreaMapping.objects.filter(ca_parent_id=0).order_by().values('ca_id', 'ca_city').distinct()

    return render(request, "customer_management/add_customer.html", {"city_list": city_list})
