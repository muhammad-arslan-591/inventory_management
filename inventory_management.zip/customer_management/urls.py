from django.urls import path
from .views import *

urlpatterns = [
    path('', customers_list, name="customers_list"),
    path('list/', customers_list, name="customers_list"),
    path('add/', add_customer, name="add_customer"),
]