import sys
import datetime
import xml.etree.ElementTree as ET
from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
from django.db import connection
from xhtml2pdf import pisa


def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html = template.render(context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None


def sequence_id(table_name="", column="", seq_name=""):
    with connection.cursor() as cursor:
        if seq_name:
            query = "select HM.{}.nextval from dual".format(seq_name)
            cursor.execute(query)
        else:
            query = "select nvl(max({})+1, 1) seq_id from HM.{}".format(column, table_name)
            cursor.execute(query)
        return cursor.fetchone()[0]


def generate_order_id(order_date):
    order_id = ''
    ord_date = datetime.datetime.strptime(order_date, "%Y-%m-%d")
    orderDateYear = ord_date.year
    with connection.cursor() as cursor:
        query = "select nvl(max(ord_seq)+1, 1) seq_id from HM.ORDERS where ord_year={}".format(orderDateYear)
        cursor.execute(query)
        max_ord_seq = cursor.fetchone()[0]
        date_ymd = order_date.replace("-", "")
        order_id = 'ORD-' + str(date_ymd) + "-" + str(max_ord_seq)
    return order_id


def extract_query(module, var):
    query = ''

    if len(sys.argv) >= 2 and sys.argv[1] == 'runserver':
        my_tree = ET.parse('./queries.xml')  # for local
    else:
        my_tree = ET.parse("<path-to-file>/queries.xml")  # for live

    my_root = my_tree.getroot()
    for x in my_root.findall(module):
        query = x.find(var).text
    return query
