import datetime

from django.shortcuts import render_to_response
from django.template import RequestContext

from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User, Group
from rest_framework import viewsets
from rest_framework import permissions
from .serializers import UserSerializer, GroupSerializer
from django.contrib.auth.decorators import login_required
from django.db.models import Sum

from django.views.generic import View
from core.utils import render_to_pdf
from setup_management.models import CityAreaMapping
from accounts_management.models import Accounts
from order_management.models import Transactions


# these are the views of main project / root application (inventory_management)

# this function will receive ajax request and return areas against city id
def get_city_areas(request):
    if request.GET and request.is_ajax():
        city_id = request.GET.get('city_id')
        areas_list = CityAreaMapping.objects.filter(ca_parent_id=city_id).order_by().values('ca_id',
                                                                                            'ca_area').distinct()
        return JsonResponse({"areas_list": list(areas_list)})


# this function will receive ajax request and return areas against city id
def get_area_customers(request):
    if request.GET:
        area_id = request.GET.get('area_id')
        customers_list = Accounts.objects.filter(acc_area=area_id, acc_type=1).order_by().values('acc_id', 'acc_name')
        # print(customers_list.query)
        return JsonResponse({"customers_list": list(customers_list)})


# this function will receive ajax request and return areas against city id
def get_dr_accounts(request):
    if request.GET:
        acc_type=0

        paid_by = request.GET.get('paid_by')
        if paid_by == 'Cash':
            acc_type = 5
        if paid_by == 'Bank':
            acc_type = 9

        dr_accounts_list = Accounts.objects.filter(acc_type=acc_type).order_by().values('acc_id', 'acc_name')
        return JsonResponse({"dr_accounts_list": list(dr_accounts_list)})


class GeneratePdf(View):
    def get(self, request, *args, **kwargs):
        data = {
            'today': datetime.date.today(),
            'amount': 39.99,
            'customer_name': 'Cooper Mann',
            'order_id': 1233434,
        }
        pdf = render_to_pdf('pdf/invoice.html', data)
        return HttpResponse(pdf, content_type='application/pdf')


# @login_required(login_url="/login/")
def home(request):

    cash_in_hand = sales = 0

    cash_account_id = Accounts.objects.filter(acc_type=5).values('acc_id')
    if cash_account_id:
        account_id = cash_account_id[0]['acc_id']
        t_cash_in_hand = Transactions.objects.filter(t_account_id=account_id).aggregate(Sum('t_debit'))
        cash_in_hand = t_cash_in_hand['t_debit__sum']

    sale_account_id = Accounts.objects.filter(acc_type=7).values('acc_id')
    if sale_account_id:
        account_id = sale_account_id[0]['acc_id']
        t_cash_in_hand = Transactions.objects.filter(t_account_id=account_id).aggregate(Sum('t_debit'))
        sales = t_cash_in_hand['t_debit__sum']

    stats_dict = {"cash_in_hand": cash_in_hand, "sales": sales}

    return render(request, "index.html", stats_dict)


def blank(request):
    return render(request, "blank.html")


def handler404(request, exception):
    response = render_to_response('404.html', {})
    response.status_code = 404
    return response


class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [permissions.IsAuthenticated]
