"""inventory_management URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
# from rest_framework import routers
from . import views as project_views

# router = routers.DefaultRouter()
# router.register(r'users', project_views.UserViewSet)
# router.register(r'groups', project_views.GroupViewSet)

urlpatterns = [
    # path('admin/', admin.site.urls),

    path('', project_views.home, name="home"),
    path('blank/', project_views.blank, name="blank"),
    path('accounts/', include('accounts_management.urls')),
    path('customers/', include('customer_management.urls')),
    path('orders/', include('order_management.urls')),
    path('stock/', include('stock_management.urls')),
    path('reports/', include('reports_management.urls')),
    path('setup/', include('setup_management.urls')),
    path('pdf/', project_views.GeneratePdf.as_view()),
    path('web-api/', include('web_apis.urls')),
    path('get_city_areas/', project_views.get_city_areas, name="get_city_areas"),
    path('get_area_customers/', project_views.get_area_customers, name="get_area_customers"),
    path('get_dr_accounts/', project_views.get_dr_accounts, name="get_dr_accounts"),

    # path('', include(router.urls)),
    # path('api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]

handler404 = 'core.views.handler404'
