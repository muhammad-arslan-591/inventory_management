from django.apps import AppConfig


class StockManagementConfig(AppConfig):
    name = 'stock_management'
