from django.urls import path
from .views import *

urlpatterns = [
    path('', product_list, name="product_list"),
    path('list/', product_list, name="product_list"),
    path('add/', add_product, name="add_product"),
    path('adjustment/', add_adjustment, name="add_adjustment"),
]