from django.db import models
from django.utils import timezone

from setup_management.models import Warehouse

# Create your models here.


class Products(models.Model):
    prd_id = models.IntegerField(primary_key=True)
    prd_name = models.CharField(max_length=50, blank=False)
    prd_code = models.CharField(max_length=25, blank=True, default='')
    prd_brand = models.IntegerField()
    prd_category = models.IntegerField()
    prd_cost = models.CharField(max_length=20, blank=True, default='')
    prd_price = models.CharField(max_length=20, blank=True, default='')
    prd_qty = models.IntegerField()
    prd_alert_qty = models.IntegerField()
    wh_id = models.IntegerField()
    prd_is_active = models.IntegerField()
    prd_created_at = models.DateTimeField(default=timezone.now)
    # prd_wh_name = models.OneToOneField(Warehouse, on_delete=None)
    # warehouse = models.ForeignKey(Warehouse, on_delete=models.CASCADE, null=True)

    class Meta:
        db_table = "products"
