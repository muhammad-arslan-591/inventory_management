from django.shortcuts import render, redirect

from .models import *
from setup_management.models import Warehouse
from core.utils import sequence_id

# Create your views here.


def product_list(request):
    productsList = Products.objects.all().order_by('prd_id')
    return render(request, "stock_management/products_list.html", {"productsList": productsList})


def add_product(request):

    wareHouseList = Warehouse.objects.all().order_by('wh_id')

    if request.POST:

        prd_obj = Products()

        prd_obj.prd_id = sequence_id("PRODUCTS", "PRD_ID")
        prd_obj.prd_name = request.POST.get('prd_name')
        prd_obj.prd_code = request.POST.get('prd_code')
        prd_obj.prd_brand = request.POST.get('prd_brand')
        prd_obj.prd_category = request.POST.get('prd_category')
        prd_obj.prd_cost = request.POST.get('prd_cost')
        prd_obj.prd_price = request.POST.get('prd_price')
        prd_obj.prd_qty = request.POST.get('prd_qty')
        prd_obj.prd_alert_qty = request.POST.get('prd_alert_qty')
        prd_obj.wh_id = request.POST.get('prd_warehouse')

        is_prd_active = request.POST.get('is_prd_active', 0)

        if is_prd_active and is_prd_active == 'on':
            is_prd_active = 1

        prd_obj.prd_is_active = is_prd_active
        prd_obj.save()

        return redirect("add_product")

    return render(request, "stock_management/add_product.html", {"wareHouseList": wareHouseList})


def add_adjustment(request):
    productsList = Products.objects.all().order_by('prd_id')

    if request.POST:

        print(request.POST)

        prd_adjust_id = request.POST.getlist("prd_adjust_id[]")
        prd_adjust_qty = request.POST.getlist("prd_adjust_qty[]")
        prd_adjust_action = request.POST.getlist("prd_adjust_action[]")

        for prd_id, adjust_qty, action in zip(prd_adjust_id, prd_adjust_qty, prd_adjust_action):
            # Products.objects.filter(prd_id=prd_id).update(prd_qty=adjust_qty)
            obj = Products.objects.get(prd_id=prd_id)
            current_prd_qty = obj.prd_qty
            if action == 'Addition':
                new_prd_qty = int(current_prd_qty) + int(adjust_qty)
                obj.prd_qty = new_prd_qty
            else:
                new_prd_qty = int(current_prd_qty) - int(adjust_qty)
                obj.prd_qty = new_prd_qty
            obj.save()

        redirect("add_adjustment")

    return render(request, "stock_management/add_product_adjustment.html", {"productsList": productsList})
