from django.urls import path
from .views import *

urlpatterns = [
    path('', accounts_list, name="accounts_list"),
    path('list/', accounts_list, name="accounts_list"),
    path('add/', add_account, name="add_account"),
]