from django.db import models
from django.utils import timezone

# Create your models here.


class Accounts(models.Model):
    acc_id = models.IntegerField(primary_key=True)
    acc_name = models.CharField(max_length=40, blank=False)
    acc_type = models.IntegerField(blank=False)
    acc_company = models.CharField(max_length=70, blank=True)
    acc_opening_balance = models.CharField(max_length=10, blank=True)
    acc_ob_status = models.CharField(max_length=6, blank=True)
    acc_contact_person = models.CharField(max_length=50, blank=True)
    acc_email = models.CharField(max_length=30, blank=True)
    acc_phone1 = models.CharField(max_length=20, blank=True)
    acc_phone2 = models.CharField(max_length=20, blank=True)
    acc_city = models.IntegerField()
    acc_area = models.IntegerField()
    acc_address = models.CharField(max_length=70, blank=True)
    acc_status = models.IntegerField(default=1)
    acc_created_by = models.IntegerField(default=1)
    acc_created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        db_table = "accounts"

