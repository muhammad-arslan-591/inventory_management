from django.shortcuts import render, redirect
from .models import *
from order_management.models import Transactions
from setup_management.models import *
from setup_management.views import sequence_id
# Create your views here.


def accounts_list(request):
    accountsList = Accounts.objects.all()
    return render(request, "accounts_management/accounts.html", {"accountsList": accountsList})


def add_account(request):
    city_list = CityAreaMapping.objects.filter(ca_parent_id=0).order_by().values('ca_id', 'ca_city').distinct()

    if request.POST:
        print(request.POST)
        accounts = Accounts()
        account_id = sequence_id("ACCOUNTS", "ACC_ID")
        accounts.acc_id = account_id
        accounts.acc_name = request.POST.get('acc_name')
        accounts.acc_type = request.POST.get('acc_type')
        accounts.acc_company = request.POST.get('company')
        accounts.acc_opening_balance = request.POST.get('opening_balance')
        balance_status = request.POST.get('balance_status')
        accounts.acc_ob_status = balance_status
        accounts.acc_contact_person = request.POST.get('contact_person')
        accounts.acc_email = request.POST.get('email_address')
        accounts.acc_phone1 = request.POST.get('phone_number1')
        accounts.acc_phone2 = request.POST.get('phone_number2')
        if request.POST.get('city'):
            city_id = request.POST.get('city')
        else:
            city_id = 0
        if request.POST.get('area'):
            area_id = request.POST.get('area')
        else:
            area_id = 0
        accounts.acc_city = city_id
        accounts.acc_area = area_id
        accounts.acc_address = request.POST.get('address')

        is_acc_active = request.POST.get('is_acc_active', 0)

        if is_acc_active and is_acc_active == 'on':
            is_acc_active = 1

        accounts.acc_status = is_acc_active
        accounts.acc_created_by = 1
        accounts.save()

        if request.POST.get('balance_status'):
            if request.POST.get('opening_balance'):
                opening_balance = request.POST.get('opening_balance')
                if int(opening_balance) > 0:
                    if balance_status == 'debit':
                        debit, credit, trans_type = opening_balance, 0, 'debit'
                    else:
                        debit, credit, trans_type = 0, opening_balance, 'credit'
                    transactions = Transactions()
                    transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
                    transactions.t_type = trans_type
                    transactions.t_account_id = account_id
                    transactions.t_description = 'Opening Balance'
                    transactions.t_debit = debit
                    transactions.t_credit = credit
                    transactions.save()

        redirect("add_account")

    return render(request, "accounts_management/add_account.html", {"city_list": city_list})
