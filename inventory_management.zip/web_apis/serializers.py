from rest_framework import serializers
from django.utils import timezone
from order_management.models import Orders


class SerializerForPOSTRequests(serializers.Serializer):
    ord_area_id = serializers.IntegerField()
    ord_cust_id = serializers.IntegerField()
    ord_tax_rate = serializers.CharField(max_length=20, default='')
    ord_tax_amt = serializers.CharField(max_length=20, default='')
    ord_disc_ttl = serializers.CharField(max_length=20, default='')
    ord_ship_cost = serializers.CharField(max_length=20, default='')
    ord_status = serializers.CharField(max_length=30, required=True)
    ord_payment_status = serializers.CharField(max_length=20, default='')
    ord_paid_by = serializers.CharField(max_length=20, default='')
    ord_cash_rcvd = serializers.CharField(max_length=20, default='')
    ord_dr_account = serializers.IntegerField()
    ord_grand_ttl = serializers.CharField(max_length=20)
    ord_date = serializers.DateField()
    ord_created_by = serializers.IntegerField()

    # class Meta: model = Orders fields = ['order_id', 'ord_cust_id', 'ord_wh_id', 'ord_tax_rate', 'ord_tax_amt',
    # 'ord_disc_ttl', 'ord_ship_cost', 'ord_status', 'ord_payment_status', 'ord_paid_by', 'ord_cash_rcvd',
    # 'ord_grand_ttl', 'ord_date', 'ord_created_by']

