from django.apps import AppConfig


class WebApisConfig(AppConfig):
    name = 'web_apis'
