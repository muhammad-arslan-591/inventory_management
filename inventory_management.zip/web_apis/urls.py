from django.urls import path
from .views import *

urlpatterns = [
    path('', CreateOrder.as_view(), name="create_order_api"),
    path('create_order/', CreateOrder.as_view(), name="create_order_api"),
    path('get_orders/', GetOrders.as_view(), name="get_orders_api"),
    path('get_order_details/<order_id>/', GetOrderDetails.as_view(), name="get_order_details_api"),
]