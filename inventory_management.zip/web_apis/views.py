import datetime
from django.http import JsonResponse
from order_management.models import *
from setup_management.views import sequence_id
from stock_management.models import Products
from accounts_management.models import Accounts

from core.utils import extract_query, generate_order_id

# --- REST API imports ---
from rest_framework.views import APIView
from rest_framework.response import Response
from . import serializers


# ------------------------

# Create your views here.
class CreateOrder(APIView):
    serializer_class = serializers.SerializerForPOSTRequests

    def post(self, request):

        # print(request.data)

        items_details = request.data['cart']
        print(items_details)
        # print(order_details['items'][0]['prd_id'])

        # pre-checks here
        # if len(order_details['items']) <= 0:
        if len(items_details) <= 0:
            return Response({'success': False, 'message': 'Order items not found', 'order_id': ''})

        serializer = serializers.SerializerForPOSTRequests(data=request.data)

        if serializer.is_valid(True):
            ord_area_id = serializer.data.get('ord_area_id')
            ord_cust_id = serializer.data.get('ord_cust_id')
            ord_tax_rate = serializer.data.get('ord_tax_rate')
            ord_tax_amt = serializer.data.get('ord_tax_amt')
            ord_disc_ttl = serializer.data.get('ord_disc_ttl')
            ord_ship_cost = serializer.data.get('ord_ship_cost')
            ord_status = serializer.data.get('ord_status')
            ord_payment_status = serializer.data.get('ord_payment_status')
            ord_paid_by = serializer.data.get('ord_paid_by')
            ord_cash_rcvd = serializer.data.get('ord_cash_rcvd')
            ord_dr_account = serializer.data.get('ord_dr_account')
            ord_grand_ttl = serializer.data.get('ord_grand_ttl')
            ord_date = serializer.data.get('ord_date')
            ord_created_by = serializer.data.get('ord_created_by')

            orderDateYear = datetime.datetime.strptime(ord_date, "%Y-%m-%d").year
            # orderDateYear = order_date.year

            print("ord_dr_account: " + str(ord_dr_account))

            if ord_payment_status == "Pending":
                ord_paid_by = ""
                ord_cash_rcvd = 0

            """ Insertion in Orders """
            orders = Orders()
            orders.ord_id = sequence_id("ORDERS", "ord_id")
            order_id = generate_order_id(ord_date)
            orders.ord_seq = order_id.split("-")[2]
            orders.order_id = order_id
            orders.ord_area_id = ord_area_id
            orders.ord_cust_id = ord_cust_id
            orders.ord_tax_rate = ord_tax_rate
            orders.ord_tax_amt = ord_tax_amt
            orders.ord_disc_ttl = ord_disc_ttl
            orders.ord_ship_cost = ord_ship_cost
            orders.ord_status = ord_status
            orders.ord_payment_status = ord_payment_status
            orders.ord_paid_by = ord_paid_by
            orders.ord_cash_rcvd = ord_cash_rcvd
            if ord_payment_status != "Pending":
                orders.ord_dr_account = ord_dr_account
            orders.ord_grand_ttl = ord_grand_ttl
            orders.ord_date = ord_date
            orders.ord_created_by = ord_created_by
            orders.ord_year = orderDateYear
            orders.save()

            for item in items_details:
                order_management_detail = OrderDetails()
                order_management_detail.od_id = sequence_id("ORDER_DETAILS", "od_id")
                order_management_detail.order_id = order_id
                order_management_detail.pro_id = item.get('product_id')
                order_management_detail.pro_qty = item.get('quantity')
                order_management_detail.pro_unit_price = item.get('price')
                order_management_detail.pro_disc_itm = item.get('item_disc')
                order_management_detail.pro_disc_ttl = item.get('item_total_disc')
                order_management_detail.pro_sub_ttl = item.get('total_price')
                order_management_detail.wh_id = item.get('wh_id')
                order_management_detail.order_date = ord_date
                order_management_detail.save()

                # update quantity in products table
                order_prd_id = item.get('product_id')
                order_prd_qty = item.get('quantity')
                obj = Products.objects.get(prd_id=order_prd_id)
                current_prd_qty = obj.prd_qty
                obj.prd_qty = int(current_prd_qty) - int(order_prd_qty)
                obj.save()

            """ Insertion in Transactions """
            transactions = Transactions()
            transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
            transactions.t_type = 'Bill'
            transactions.t_account_id = ord_cust_id
            transactions.t_description = order_id
            transactions.t_debit = ord_grand_ttl
            transactions.t_credit = 0
            transactions.t_order_date = ord_date
            transactions.save()

            transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
            transactions.t_type = 'Sale'
            sale_account_id = Accounts.objects.filter(acc_type=7).values('acc_id')
            transactions.t_account_id = sale_account_id[0]['acc_id']
            transactions.t_description = order_id
            transactions.t_debit = ord_grand_ttl
            transactions.t_credit = 0
            transactions.t_date = ord_date
            transactions.save()

            if ord_payment_status != "Pending":
                transactions = Transactions()
                transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
                transactions.t_type = 'Customer Payment'
                transactions.t_account_id = ord_cust_id
                transactions.t_description = order_id
                transactions.t_debit = 0
                transactions.t_credit = ord_cash_rcvd
                transactions.t_order_date = ord_date
                transactions.save()

                transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
                transactions.t_type = 'Cash ' + str(ord_paid_by)
                transactions.t_account_id = ord_dr_account
                transactions.t_description = order_id
                transactions.t_debit = ord_cash_rcvd
                transactions.t_credit = 0
                transactions.t_date = ord_date
                transactions.save()

            message = 'Order created successfully'

            return Response({'success': True, 'message': message, 'order_id': order_id})
        else:
            return Response(serializer.errors)


class GetOrders(APIView):

    def get(self, request):

        subquery = ""
        order_id = request.GET.get("order_id")
        order_status = request.GET.get("order_status")

        if order_id:
            subquery = " AND ORD.ORDER_ID = '{}' ".format(order_id)

        if order_status and (order_status != 'active' and order_status != 'non-active'):
            return JsonResponse({
                'message': "Please pass 'active' or 'non-active' as order status"
            })

        if order_status == 'active':
            subquery += " AND ORD.ORD_STATUS = 'Open' "
        elif order_status == 'non-active':
            subquery += " AND ORD.ORD_STATUS != 'Open' "

        ordersListQuery = extract_query("WebAPIs", "./OrderManagement/get_orders")
        ordersListQuery = ordersListQuery.format(subquery)
        orders = Orders.objects.raw(ordersListQuery)

        orders_list = []

        if len(orders) > 0:
            for order in orders:
                orders_list.append({
                    "order_id": order.order_id,
                    "order_date": order.ord_date,
                    "customer_id": order.ord_cust_id,
                    "customer_name": order.acc_name,
                    "order_status": order.ord_status,
                    "payment_status": order.ord_payment_status,
                    "paid_amount": order.ord_cash_rcvd,
                    "tax_amount": order.ord_tax_amt,
                    "order_amount": order.ord_grand_ttl
                })

            return Response({"status": "success", "data": orders_list})
        else:
            return JsonResponse({
                'code': 404,
                'message': 'No orders found'
            })


class GetOrderDetails(APIView):

    def get(self, request, order_id):

        ordersDetailQuery = extract_query("WebAPIs", "./OrderManagement/get_order_detail")
        ordersDetailQuery = ordersDetailQuery.format(order_id)
        order_details = OrderDetails.objects.raw(ordersDetailQuery)

        order_details_list = []

        if len(order_details) > 0:
            for order in order_details:
                order_details_list.append({
                    "prd_id": order.pro_id,
                    "prd_name": order.prd_name,
                    "prd_qty": order.pro_qty,
                    "prd_unit_price": order.pro_unit_price,
                    "prd_disc_itm": order.pro_disc_itm,
                    "prd_disc_ttl": order.pro_disc_ttl,
                    "prd_sub_ttl": order.pro_sub_ttl
                })

            return Response({"status": "success", "data": order_details_list})
        else:
            return JsonResponse({
                'code': 404,
                'message': 'Order details not found'
            })
