from django.apps import AppConfig


class OrderManagementConfig(AppConfig):
    name = 'order_management'
