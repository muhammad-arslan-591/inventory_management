import datetime
import json
import requests
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Sum
from django.http import HttpResponse
from django.shortcuts import render, redirect

from .models import *
from setup_management.models import *
from stock_management.models import Products
from accounts_management.models import Accounts
from core.utils import sequence_id, extract_query, generate_order_id


# Create your views here.


def orders_list(request):
    ordersList = Orders.objects.all()
    return render(request, "order_management/orders_list.html", {'ordersList': ordersList})


def order_invoice(request, order_id):

    order_data = ""
    order_detail_data = ""

    if request.is_secure():
        protocol = 'https'
    else:
        protocol = 'http'

    host = request.get_host()

    order_request_url = protocol + '://' + host + '/web-api/get_orders/?order_id=' + order_id
    response = requests.get(order_request_url)
    if response.status_code == 200:
        order_data = response.json()

    order_detail_request_url = protocol + '://' + host + '/web-api/get_order_details/%s' % order_id
    response = requests.get(order_detail_request_url)
    if response.status_code == 200:
        order_detail_data = response.json()

    sum_prd_disc_ttl = OrderDetails.objects.filter(order_id=order_id).aggregate(Sum('pro_disc_ttl'))['pro_disc_ttl__sum']
    sum_prd_sub_ttl = OrderDetails.objects.filter(order_id=order_id).aggregate(Sum('pro_sub_ttl'))['pro_sub_ttl__sum']
    sum_prd_sub_ttl_with_discount = int(float(sum_prd_sub_ttl) + float(sum_prd_disc_ttl))

    data_dict = {
        'order': order_data, 'order_detail': order_detail_data,
        'sum_prd_disc_ttl': sum_prd_disc_ttl,
        'sum_prd_sub_ttl': sum_prd_sub_ttl,
        'sum_prd_sub_ttl_with_discount': sum_prd_sub_ttl_with_discount
    }

    return render(request, "order_management/invoices/bill_invoice.html", data_dict)


def view_order(request, order_id):
    try:
        order = Orders.objects.get(order_id=order_id)
    except ObjectDoesNotExist as e:
        return render(request, "order_management/view_order.html", {"message": str(e), "alert_type": "danger"})
        # response_dict.update({'message': str(e)})
        # return HttpResponse(json.dumps(response_dict))

    orderDetailsQuery = extract_query("OrderManagement", "./get_order_items_detail")
    orderDetailsQuery = orderDetailsQuery.format(order_id)
    orderDetails = OrderDetails.objects.raw(orderDetailsQuery)

    """ Get data for LOVs """
    productsListQuery = extract_query("StockManagement", "./get_all_products")
    productsList = Products.objects.raw(productsListQuery)
    wareHouseList = Warehouse.objects.all().order_by('wh_id')
    area_list = CityAreaMapping.objects.exclude(ca_parent_id=0).order_by().values('ca_id', 'ca_area').distinct()

    order_tax_list = {"0": "No Tax", "0.17": "VAT@17"}
    order_status_list = ["Open", "Processing", "Pending", "Delivered"]
    payment_status_list = ["Pending", "Partial", "Paid"]
    paid_by_list = ["Cash", "Bank"]

    data_dict = {'order': order, "orderDetails": orderDetails, "area_list": area_list, "wareHouseList": wareHouseList,
                 "productsList": productsList, "order_status_list": order_status_list,
                 "payment_status_list": payment_status_list, "paid_by_list": paid_by_list,
                 "order_tax_list": order_tax_list}

    """ Update Order Request """

    if request.POST:

        print(request.POST)

        """ Header """
        area = request.POST.get('area')
        customer = request.POST.get('customer')
        orderDate = request.POST.get('orderDate')
        orderDate = datetime.datetime.strptime(orderDate, "%d-%b-%y").strftime("%Y-%m-%d")
        # ord_date = datetime.datetime.strptime(orderDate, "%Y-%m-%d")
        # orderDateYear = ord_date.year

        """ Orders Detail """
        order_prd_id = request.POST.getlist("order_prd_id[]")
        order_wh_id = request.POST.getlist("order_wh_id[]")
        order_qty = request.POST.getlist("order_qty[]")
        order_old_qty = request.POST.getlist("order_old_qty[]")
        order_unit_price = request.POST.getlist("order_unit_price[]")
        order_disc_per_item = request.POST.getlist("order_discount_per_item[]")
        order_total_disc_per_item = request.POST.getlist("order_total_discount_per_item[]")
        order_sub_total = request.POST.getlist("order_sub_total[]")

        """ Footer """
        orderTax = request.POST.get('orderTax')
        discount = request.POST.get('discount')
        shippingCost = request.POST.get('shippingCost')
        orderStatus = request.POST.get('orderStatus')
        paymentStatus = request.POST.get('paymentStatus')
        paidBy = request.POST.get('paidBy')
        dr_account = request.POST.get('dr_account')
        payingAmount = request.POST.get('payingAmount')
        orderTaxAmount = request.POST.get('orderTaxAmount')
        grandTotal = request.POST.get('grandTotal')

        if paymentStatus == 'Pending':
            paidBy = ""
            payingAmount = 0

        """ Update Header """
        Orders.objects.filter(order_id=order_id).update(ord_area_id=area, ord_cust_id=customer, ord_date=orderDate)

        """ Update Body """
        OrderDetails.objects.filter(order_id=order_id).delete()
        Transactions.objects.filter(t_description=order_id).delete()

        """ Insertion in Order Details """
        for o_prd_id, o_wh_id, o_qty, o_old_qty, o_up, o_dpi, o_tdpi, o_st in zip(order_prd_id, order_wh_id, order_qty,
                                                                                  order_old_qty, order_unit_price,
                                                                                  order_disc_per_item,
                                                                                  order_total_disc_per_item,
                                                                                  order_sub_total):
            order_management_detail = OrderDetails()
            order_management_detail.od_id = sequence_id("ORDER_DETAILS", "od_id")
            order_management_detail.order_id = order_id
            order_management_detail.pro_id = o_prd_id
            order_management_detail.pro_qty = o_qty
            order_management_detail.pro_unit_price = o_up
            order_management_detail.pro_disc_itm = o_dpi
            order_management_detail.pro_disc_ttl = o_tdpi
            order_management_detail.pro_sub_ttl = o_st
            order_management_detail.wh_id = o_wh_id
            order_management_detail.order_date = orderDate
            order_management_detail.save()

            if o_qty != o_old_qty:
                print("New quantity is different")
                # update quantity in products table
                prd_obj = Products.objects.get(prd_id=o_prd_id)
                current_prd_qty = prd_obj.prd_qty

                if int(o_qty) > int(o_old_qty):
                    print("New quantity is greater than old")
                    new_prd_qty = int(current_prd_qty) - (int(o_qty) - int(o_old_qty))
                    prd_obj.prd_qty = new_prd_qty
                    prd_obj.save()
                else:
                    print("New quantity is lower than old")
                    new_prd_qty = int(current_prd_qty) + (int(o_old_qty) - int(o_qty))
                    prd_obj.prd_qty = new_prd_qty
                    prd_obj.save()
            else:
                print("Both are same, no action will be performed in products")

        """ Insertion in Transactions """
        transactions = Transactions()
        transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
        transactions.t_type = 'Bill'
        transactions.t_account_id = customer
        transactions.t_description = order_id
        transactions.t_debit = grandTotal
        transactions.t_credit = 0
        transactions.t_date = orderDate
        transactions.save()

        transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
        transactions.t_type = 'Sale'
        sale_account_id = Accounts.objects.filter(acc_type=7).values('acc_id')
        transactions.t_account_id = sale_account_id[0]['acc_id']
        transactions.t_description = order_id
        transactions.t_debit = grandTotal
        transactions.t_credit = 0
        transactions.t_date = orderDate
        transactions.save()

        if paymentStatus != "Pending":
            transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
            transactions.t_type = 'Customer Payment'
            transactions.t_account_id = customer
            transactions.t_description = order_id
            transactions.t_debit = 0
            transactions.t_credit = payingAmount
            transactions.t_date = orderDate
            transactions.save()

            transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
            transactions.t_type = paidBy + " Payment"
            transactions.t_account_id = dr_account
            transactions.t_description = order_id
            transactions.t_debit = payingAmount
            transactions.t_credit = 0
            transactions.t_date = orderDate
            transactions.save()

        """ Update Footer """

        Orders.objects.filter(order_id=order_id).update(
            ord_tax_rate=orderTax, ord_tax_amt=orderTaxAmount,
            ord_disc_ttl=discount, ord_ship_cost=shippingCost,
            ord_status=orderStatus, ord_payment_status=paymentStatus,
            ord_paid_by=paidBy, ord_cash_rcvd=payingAmount,
            ord_dr_account=dr_account, ord_grand_ttl=grandTotal
        )

        data_dict.update({"message": "Order Updated Successfully", "alert_type": "success"})
        return render(request, "order_management/view_order.html", data_dict)

    return render(request, "order_management/view_order.html", data_dict)


def create_order(request):
    """ Get data for LOVs """
    productsListQuery = extract_query("StockManagement", "./get_all_products")
    productsList = Products.objects.raw(productsListQuery)
    wareHouseList = Warehouse.objects.all().order_by('wh_id')
    area_list = CityAreaMapping.objects.exclude(ca_parent_id=0).order_by().values('ca_id', 'ca_area').distinct()

    order_tax_list = {"0": "No Tax", "0.17": "VAT@17"}
    order_status_list = ["Open", "Processing", "Pending", "Delivered"]
    payment_status_list = ["Pending", "Partial", "Paid"]
    paid_by_list = ["Cash", "Bank"]

    data_dict = {"area_list": area_list, "productsList": productsList, "wareHouseList": wareHouseList,
                 "order_status_list": order_status_list, "payment_status_list": payment_status_list,
                 "paid_by_list": paid_by_list, "order_tax_list": order_tax_list}

    if request.POST.get('customer'):

        """ Header """
        area = request.POST.get('area')
        customer = request.POST.get('customer')
        orderDate = request.POST.get('orderDate')
        order_date = datetime.datetime.strptime(orderDate, "%Y-%m-%d")
        orderDateYear = order_date.year

        """ Orders Detail """
        order_prd_id = request.POST.getlist("order_prd_id[]")
        order_wh_id = request.POST.getlist("order_wh_id[]")
        order_qty = request.POST.getlist("order_qty[]")
        order_unit_price = request.POST.getlist("order_unit_price[]")
        order_disc_per_item = request.POST.getlist("order_discount_per_item[]")
        order_total_disc_per_item = request.POST.getlist("order_total_discount_per_item[]")
        order_sub_total = request.POST.getlist("order_sub_total[]")

        """ Footer """
        orderTax = request.POST.get('orderTax')
        discount = request.POST.get('discount')
        shippingCost = request.POST.get('shippingCost')
        orderStatus = request.POST.get('orderStatus')
        paymentStatus = request.POST.get('paymentStatus')
        paidBy = request.POST.get('paidBy')
        # receivedAmount = request.POST.get('receivedAmount')
        payingAmount = request.POST.get('payingAmount')
        dr_account = request.POST.get('dr_account')
        orderTaxAmount = request.POST.get('orderTaxAmount')
        grandTotal = request.POST.get('grandTotal')

        if paymentStatus == "Pending":
            paidBy = ""
            payingAmount = 0

        """ Insertion in Orders """
        order_management = Orders()
        order_management.ord_id = sequence_id("ORDERS", "ord_id")
        order_id = generate_order_id(orderDate)
        order_management.ord_seq = order_id.split("-")[2]
        order_management.order_id = order_id
        order_management.ord_area_id = area
        order_management.ord_cust_id = customer
        order_management.ord_tax_rate = orderTax
        order_management.ord_tax_amt = orderTaxAmount
        order_management.ord_disc_ttl = discount
        order_management.ord_ship_cost = shippingCost
        order_management.ord_status = orderStatus
        order_management.ord_payment_status = paymentStatus
        order_management.ord_paid_by = paidBy
        order_management.ord_cash_rcvd = payingAmount
        if paymentStatus != "Pending":
            order_management.ord_dr_account = dr_account
        order_management.ord_grand_ttl = grandTotal
        order_management.ord_date = orderDate
        order_management.ord_created_by = 1
        order_management.ord_year = orderDateYear
        order_management.save()

        """ Insertion in Order Details """
        for o_prd_id, o_wh_id, o_qty, o_up, o_dpi, o_tdpi, o_st in zip(order_prd_id, order_wh_id, order_qty,
                                                                       order_unit_price,
                                                                       order_disc_per_item, order_total_disc_per_item,
                                                                       order_sub_total):
            order_management_detail = OrderDetails()
            order_management_detail.od_id = sequence_id("ORDER_DETAILS", "od_id")
            order_management_detail.order_id = order_id
            order_management_detail.pro_id = o_prd_id
            order_management_detail.pro_qty = o_qty
            order_management_detail.pro_unit_price = o_up
            order_management_detail.pro_disc_itm = o_dpi
            order_management_detail.pro_disc_ttl = o_tdpi
            order_management_detail.pro_sub_ttl = o_st
            order_management_detail.wh_id = o_wh_id
            order_management_detail.order_date = orderDate
            order_management_detail.save()

            # Products.objects.filter(prd_id=o_prd_id).update(prd_qty=o_qty)
            # update quantity in products table
            obj = Products.objects.get(prd_id=o_prd_id)
            current_prd_qty = obj.prd_qty
            obj.prd_qty = int(current_prd_qty) - int(o_qty)
            obj.save()

        """ Insertion in Transactions """
        transactions = Transactions()
        transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
        transactions.t_type = 'Bill'
        transactions.t_account_id = customer
        transactions.t_description = order_id
        transactions.t_debit = grandTotal
        transactions.t_credit = 0
        transactions.t_date = orderDate
        transactions.save()

        transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
        transactions.t_type = 'Sale'
        sale_account_id = Accounts.objects.filter(acc_type=7).values('acc_id')
        transactions.t_account_id = sale_account_id[0]['acc_id']
        transactions.t_description = order_id
        transactions.t_debit = grandTotal
        transactions.t_credit = 0
        transactions.t_date = orderDate
        transactions.save()

        if paymentStatus != "Pending":
            transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
            transactions.t_type = 'Customer Payment'
            transactions.t_account_id = customer
            transactions.t_description = order_id
            transactions.t_debit = 0
            transactions.t_credit = payingAmount
            transactions.t_date = orderDate
            transactions.save()

            transactions.t_id = sequence_id("TRANSACTIONS", "t_id")
            transactions.t_type = paidBy + " Payment"
            transactions.t_account_id = dr_account
            transactions.t_description = order_id
            transactions.t_debit = payingAmount
            transactions.t_credit = 0
            transactions.t_date = orderDate
            transactions.save()

        return redirect("orders_list")

    return render(request, "order_management/create_order.html", data_dict)
