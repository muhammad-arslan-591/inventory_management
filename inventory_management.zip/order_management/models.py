from django.db import models
from django.utils import timezone
from setup_management.models import Warehouse


# Create your models here.
# class Tutorial(models.Model):
#     id = models.IntegerField(primary_key=True)
#     title = models.CharField(max_length=70, blank=False, default='')
#     description = models.CharField(max_length=200, blank=False, default='')
#     published = models.BooleanField(default=False)
#
#     class Meta:
#         db_table = "tutorials"


class Orders(models.Model):
    ord_id = models.IntegerField(primary_key=True)
    ord_seq = models.IntegerField()
    order_id = models.CharField(max_length=20, blank=False)
    ord_area_id = models.IntegerField()
    ord_cust_id = models.IntegerField()
    ord_tax_rate = models.CharField(max_length=20, blank=True, default='')
    ord_tax_amt = models.CharField(max_length=20, blank=True, default='')
    ord_disc_ttl = models.CharField(max_length=20, blank=True, default='')
    ord_ship_cost = models.CharField(max_length=20, blank=True, default='')
    ord_status = models.CharField(max_length=30, blank=False)
    ord_payment_status = models.CharField(max_length=20, blank=True, default='')
    ord_paid_by = models.CharField(max_length=20, blank=True, default='')
    ord_cash_rcvd = models.CharField(max_length=20, blank=True, default='')
    ord_dr_account = models.IntegerField()
    ord_grand_ttl = models.CharField(max_length=20, blank=False)
    ord_date = models.DateField()
    ord_created_by = models.IntegerField()
    ord_created_at = models.DateTimeField(default=timezone.now)
    ord_upd_by = models.IntegerField()
    ord_upd_at = models.DateField()
    ord_year = models.IntegerField()

    class Meta:
        db_table = "orders"


class OrderDetails(models.Model):
    od_id = models.IntegerField(primary_key=True)
    order_id = models.CharField(max_length=20, blank=False)
    pro_id = models.CharField(max_length=25, blank=False)
    pro_qty = models.CharField(max_length=10, blank=False)
    pro_unit_price = models.CharField(max_length=10, blank=False)
    pro_disc_itm = models.CharField(max_length=20, blank=False)
    pro_disc_ttl = models.CharField(max_length=20, blank=False)
    pro_sub_ttl = models.CharField(max_length=20, blank=False)
    wh_id = models.IntegerField()
    order_date = models.DateField()
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateField()

    class Meta:
        db_table = "order_details"


class Transactions(models.Model):
    t_id = models.IntegerField(primary_key=True)
    t_type = models.CharField(max_length=25, blank=True, default='')
    t_account_id = models.CharField(max_length=5, blank=False)
    t_description = models.CharField(max_length=70, blank=True)
    t_debit = models.CharField(max_length=10, blank=False)
    t_credit = models.CharField(max_length=10, blank=False)
    t_date = models.DateField(default=timezone.now)
    t_created_at = models.DateTimeField(default=timezone.now)
    t_updated_at = models.DateField()

    class Meta:
        db_table = "transactions"
