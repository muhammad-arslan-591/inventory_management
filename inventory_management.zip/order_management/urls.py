from django.urls import path

from .views import *

urlpatterns = [
    path('', orders_list, name="orders_list"),
    path('list/', orders_list, name="orders_list"),
    path('create/', create_order, name="create_order"),
    path('view/<order_id>/', view_order, name="view_order"),
    path('invoice/<order_id>/', order_invoice, name="order_invoice"),
]