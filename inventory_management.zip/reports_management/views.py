import datetime
from django.shortcuts import render
from django.http import HttpResponse
from django.db.models import Sum
from django.db import connection

# imports for pdf generation
from core.utils import render_to_pdf

from order_management.models import Transactions
from accounts_management.models import Accounts


# Create your views here.


def generate_ledger_report(request):

    accountsList = Accounts.objects.all()

    if request.POST:
        dr_sum_ob = cr_sum_ob = dr_sum_cb = cr_sum_cb = opening_balance = closing_balance = 0
        from_date = request.POST.get('fromDate')
        to_date = request.POST.get('toDate')
        account = request.POST.get('account')

        account_id, account_name = account.split('~')

        """ # fetch transaction records """
        result = Transactions.objects.filter(t_account_id=account_id, t_date__gte=from_date,
                                             t_date__lte=to_date).order_by('t_date', 't_id')

        """ # start calculating opening balance and closing balance """
        t_dr_cr_sum_for_ob = Transactions.objects.filter(t_account_id=account_id, t_date__lt=from_date).aggregate(Sum('t_debit'), Sum('t_credit'))
        dr_sum_ob = t_dr_cr_sum_for_ob['t_debit__sum']
        cr_sum_ob = t_dr_cr_sum_for_ob['t_credit__sum']

        if dr_sum_ob != '' and cr_sum_ob != '' :
            opening_balance = dr_sum_ob - cr_sum_ob

        t_dr_cr_sum_for_cb = Transactions.objects.filter(t_account_id=account_id, t_date__gte=from_date, t_date__lte=to_date).aggregate(Sum('t_debit'), Sum('t_credit'))

        dr_sum_cb = t_dr_cr_sum_for_cb['t_debit__sum']
        cr_sum_cb = t_dr_cr_sum_for_cb['t_credit__sum']

        if dr_sum_cb != '' and cr_sum_cb != '':
            closing_balance = opening_balance + dr_sum_cb - cr_sum_cb

        print('opening_balance: ' + str(round(opening_balance)))
        print('closing_balance: ' + str(round(closing_balance)))

        """ # end calculating opening balance and closing balance """

        data = {
            'account': account_name,
            'fromDate': from_date,
            'toDate': to_date,
            'searchResult': result,
            'opening_balance': opening_balance,
            'closing_balance': closing_balance
        }
        pdf = render_to_pdf('pdf/ledger_report_pdf.html', data)
        return HttpResponse(pdf, content_type='application/pdf')
    return render(request, "reports_management/ledger_report.html", {"accountsList": accountsList})


def general_summary_report(request):
    accountsList = Accounts.objects.filter(acc_type=2)

    if request.POST:

        fromDate = request.POST.get("fromDate")
        toDate = request.POST.get("toDate")

        distributors = []

        if request.POST.get("account"):
            distributors.append(request.POST.get("account"))
        else:
            for account in accountsList:
                distributors.append(str(account.acc_id)+"~"+str(account.acc_name))

        data = {"fromDate": fromDate, "toDate": toDate}
        print(distributors)

        return render(request, "reports_management/html/general_summary_report_template.html", data)

    return render(request, "reports_management/general_summary_report.html", {"accountsList": accountsList})