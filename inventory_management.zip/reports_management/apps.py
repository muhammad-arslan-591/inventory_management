from django.apps import AppConfig


class ReportsManagementConfig(AppConfig):
    name = 'reports_management'
