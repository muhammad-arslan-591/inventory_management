from django.urls import path

from .views import *

urlpatterns = [
    path('', generate_ledger_report, name="generate_ledger_report"),
    path('general/ledger/', generate_ledger_report, name="generate_ledger_report"),
    path('general/summary/', general_summary_report, name="general_summary_report"),
]